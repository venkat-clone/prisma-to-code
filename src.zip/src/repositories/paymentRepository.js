const prisma = require('../config/config');
    
    const getPaymentById = async (id) => {
    return await prisma.payment.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createPayment = async (data,  options = {}) => {
    return await prisma.payment.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updatePayment = async (id, data) => {
        return await prisma.payment.update({
            where: { id: id },
            data,
        });
    };
    
    const deletePayment = async (id) => {
    return await prisma.payment.delete({ where: { id: Number(id) } });
};

    const getPayments = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Payments, count] = await prisma.$transaction([
        prisma.payment.findMany(query),
        prisma.payment.count({ where: query.where })
    ]);

    return { Payments, count };
};
    
    module.exports = {
        getPaymentById,
        createPayment,
        updatePayment,
        deletePayment,
        getPayments
    };
    