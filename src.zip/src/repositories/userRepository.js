const prisma = require('../config/config');
    
    const getUserById = async (id) => {
    return await prisma.user.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createUser = async (data,  options = {}) => {
    return await prisma.user.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateUser = async (id, data) => {
        return await prisma.user.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteUser = async (id) => {
    return await prisma.user.update({
        where: { id: Number(id) },
        data: { inactive: false },
    });
};

    const getUsers = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Users, count] = await prisma.$transaction([
        prisma.user.findMany(query),
        prisma.user.count({ where: query.where })
    ]);

    return { Users, count };
};
    
    module.exports = {
        getUserById,
        createUser,
        updateUser,
        deleteUser,
        getUsers
    };
    