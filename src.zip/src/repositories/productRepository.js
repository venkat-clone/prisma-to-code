const prisma = require('../config/config');
    
    const getProductById = async (id) => {
    return await prisma.product.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createProduct = async (data,  options = {}) => {
    return await prisma.product.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateProduct = async (id, data) => {
        return await prisma.product.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteProduct = async (id) => {
    return await prisma.product.delete({ where: { id: Number(id) } });
};

    const getProducts = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Products, count] = await prisma.$transaction([
        prisma.product.findMany(query),
        prisma.product.count({ where: query.where })
    ]);

    return { Products, count };
};
    
    module.exports = {
        getProductById,
        createProduct,
        updateProduct,
        deleteProduct,
        getProducts
    };
    