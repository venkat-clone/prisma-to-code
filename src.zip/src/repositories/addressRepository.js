const prisma = require('../config/config');
    
    const getAddressById = async (id) => {
    return await prisma.address.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createAddress = async (data,  options = {}) => {
    return await prisma.address.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateAddress = async (id, data) => {
        return await prisma.address.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteAddress = async (id) => {
    return await prisma.address.delete({ where: { id: Number(id) } });
};

    const getAddresss = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Addresss, count] = await prisma.$transaction([
        prisma.address.findMany(query),
        prisma.address.count({ where: query.where })
    ]);

    return { Addresss, count };
};
    
    module.exports = {
        getAddressById,
        createAddress,
        updateAddress,
        deleteAddress,
        getAddresss
    };
    