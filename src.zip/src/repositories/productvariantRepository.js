const prisma = require('../config/config');
    
    const getProductVariantById = async (id) => {
    return await prisma.productvariant.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createProductVariant = async (data,  options = {}) => {
    return await prisma.productvariant.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateProductVariant = async (id, data) => {
        return await prisma.productvariant.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteProductVariant = async (id) => {
    return await prisma.productvariant.delete({ where: { id: Number(id) } });
};

    const getProductVariants = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [ProductVariants, count] = await prisma.$transaction([
        prisma.productvariant.findMany(query),
        prisma.productvariant.count({ where: query.where })
    ]);

    return { ProductVariants, count };
};
    
    module.exports = {
        getProductVariantById,
        createProductVariant,
        updateProductVariant,
        deleteProductVariant,
        getProductVariants
    };
    