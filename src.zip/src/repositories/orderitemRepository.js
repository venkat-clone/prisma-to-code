const prisma = require('../config/config');
    
    const getOrderItemById = async (id) => {
    return await prisma.orderitem.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createOrderItem = async (data,  options = {}) => {
    return await prisma.orderitem.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateOrderItem = async (id, data) => {
        return await prisma.orderitem.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteOrderItem = async (id) => {
    return await prisma.orderitem.delete({ where: { id: Number(id) } });
};

    const getOrderItems = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [OrderItems, count] = await prisma.$transaction([
        prisma.orderitem.findMany(query),
        prisma.orderitem.count({ where: query.where })
    ]);

    return { OrderItems, count };
};
    
    module.exports = {
        getOrderItemById,
        createOrderItem,
        updateOrderItem,
        deleteOrderItem,
        getOrderItems
    };
    