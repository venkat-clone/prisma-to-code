const prisma = require('../config/config');
    
    const getCartItemById = async (id) => {
    return await prisma.cartitem.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createCartItem = async (data,  options = {}) => {
    return await prisma.cartitem.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateCartItem = async (id, data) => {
        return await prisma.cartitem.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteCartItem = async (id) => {
    return await prisma.cartitem.delete({ where: { id: Number(id) } });
};

    const getCartItems = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            product: true,
            size: true,
            color: true
        },
        ...options
    };

    const [CartItems, count] = await prisma.$transaction([
        prisma.cartitem.findMany(query),
        prisma.cartitem.count({ where: query.where })
    ]);

    return { CartItems, count };
};
    
    module.exports = {
        getCartItemById,
        createCartItem,
        updateCartItem,
        deleteCartItem,
        getCartItems
    };
    