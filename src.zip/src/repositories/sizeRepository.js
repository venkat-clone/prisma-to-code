const prisma = require('../config/config');
    
    const getSizeById = async (id) => {
    return await prisma.size.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createSize = async (data,  options = {}) => {
    return await prisma.size.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateSize = async (id, data) => {
        return await prisma.size.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteSize = async (id) => {
    return await prisma.size.delete({ where: { id: Number(id) } });
};

    const getSizes = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Sizes, count] = await prisma.$transaction([
        prisma.size.findMany(query),
        prisma.size.count({ where: query.where })
    ]);

    return { Sizes, count };
};
    
    module.exports = {
        getSizeById,
        createSize,
        updateSize,
        deleteSize,
        getSizes
    };
    