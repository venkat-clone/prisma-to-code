const prisma = require('../config/config');
    
    const getCartById = async (id) => {
    return await prisma.cart.findUnique({
        where: { id: Number(id) },
        include: {
            products: true
        }
    });
};
    
    const createCart = async (data, products = [], options = {}) => {
    return await prisma.cart.create({
        data: {
            ...data,
            
            ...(data.products && data.products.length > 0 && {
                products: {
                    create: products,
                }
            })
        },
        
    });
};
    
    const updateCart = async (id, data) => {
        return await prisma.cart.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteCart = async (id) => {
    return await prisma.cart.delete({ where: { id: Number(id) } });
};

    const getCarts = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            user: true
        },
        ...options
    };

    const [Carts, count] = await prisma.$transaction([
        prisma.cart.findMany(query),
        prisma.cart.count({ where: query.where })
    ]);

    return { Carts, count };
};
    
    module.exports = {
        getCartById,
        createCart,
        updateCart,
        deleteCart,
        getCarts
    };
    