const prisma = require('../config/config');
    
    const getTimerById = async (id) => {
    return await prisma.timer.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createTimer = async (data,  options = {}) => {
    return await prisma.timer.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateTimer = async (id, data) => {
        return await prisma.timer.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteTimer = async (id) => {
    return await prisma.timer.delete({ where: { id: Number(id) } });
};

    const getTimers = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Timers, count] = await prisma.$transaction([
        prisma.timer.findMany(query),
        prisma.timer.count({ where: query.where })
    ]);

    return { Timers, count };
};
    
    module.exports = {
        getTimerById,
        createTimer,
        updateTimer,
        deleteTimer,
        getTimers
    };
    