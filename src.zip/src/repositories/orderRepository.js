const prisma = require('../config/config');
    
    const getOrderById = async (id) => {
    return await prisma.order.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createOrder = async (data,  options = {}) => {
    return await prisma.order.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateOrder = async (id, data) => {
        return await prisma.order.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteOrder = async (id) => {
    return await prisma.order.delete({ where: { id: Number(id) } });
};

    const getOrders = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Orders, count] = await prisma.$transaction([
        prisma.order.findMany(query),
        prisma.order.count({ where: query.where })
    ]);

    return { Orders, count };
};
    
    module.exports = {
        getOrderById,
        createOrder,
        updateOrder,
        deleteOrder,
        getOrders
    };
    