const prisma = require('../config/config');
    
    const getColorById = async (id) => {
    return await prisma.color.findUnique({
        where: { id: Number(id) },
        include: {
            
        }
    });
};
    
    const createColor = async (data,  options = {}) => {
    return await prisma.color.create({
        data: {
            ...data,
            
        },
        
    });
};
    
    const updateColor = async (id, data) => {
        return await prisma.color.update({
            where: { id: id },
            data,
        });
    };
    
    const deleteColor = async (id) => {
    return await prisma.color.delete({ where: { id: Number(id) } });
};

    const getColors = async (where, skip, take, orderBy, options = {}) => {
    const query = {
        where,
        skip,
        take,
        orderBy,
        include: {
            
        },
        ...options
    };

    const [Colors, count] = await prisma.$transaction([
        prisma.color.findMany(query),
        prisma.color.count({ where: query.where })
    ]);

    return { Colors, count };
};
    
    module.exports = {
        getColorById,
        createColor,
        updateColor,
        deleteColor,
        getColors
    };
    