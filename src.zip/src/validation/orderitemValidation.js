
const { z } = require('zod');
const OrderItemSchema = z.object({
    cartId: z.number().int(),
    productId: z.number().int(),
    quantity: z.number().int(),
    price: z.number().int()
});

const updateOrderItemSchema = z.object({
    cartId: z.number().int().optional(),
    productId: z.number().int().optional(),
    quantity: z.number().int().optional(),
    price: z.number().int().optional()
});

module.exports = {OrderItemSchema, updateOrderItemSchema};
