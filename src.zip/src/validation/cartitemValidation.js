
const { z } = require('zod');
const CartItemSchema = z.object({
    cartId: z.number().int(),
    productId: z.number().int(),
    quantity: z.number().int(),
    price: z.number().int(),
    sizeid: z.number().int(),
    colorid: z.number().int()
});

const updateCartItemSchema = z.object({
    cartId: z.number().int().optional(),
    productId: z.number().int().optional(),
    quantity: z.number().int().optional(),
    price: z.number().int().optional(),
    sizeid: z.number().int().optional(),
    colorid: z.number().int().optional()
});

module.exports = {CartItemSchema, updateCartItemSchema};
