
const { z } = require('zod');
const CartSchema = z.object({
    userId: z.number().int()
});

const updateCartSchema = z.object({
    userId: z.number().int().optional()
});

module.exports = {CartSchema, updateCartSchema};
