
const { z } = require('zod');
const PaymentSchema = z.object({
    status: z.enum(['PENDING', 'FAILED', 'SUCCESS', 'REFUNDED', 'CANCELLED']),
    type: z.enum(['CASH_ON_DELIVERY', 'CARD', 'UPI']),
    amount: z.number().int(),
    orderId: z.number().int().optional(),
    TransactionId: z.string(),
    from: z.string(),
    to: z.string()
});

const updatePaymentSchema = z.object({
    status: z.enum(['PENDING', 'FAILED', 'SUCCESS', 'REFUNDED', 'CANCELLED']).optional(),
    type: z.enum(['CASH_ON_DELIVERY', 'CARD', 'UPI']).optional(),
    amount: z.number().int().optional(),
    orderId: z.number().int().optional(),
    TransactionId: z.string().optional(),
    from: z.string().optional(),
    to: z.string().optional()
});

module.exports = {PaymentSchema, updatePaymentSchema};
