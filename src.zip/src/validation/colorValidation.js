
const { z } = require('zod');
const ColorSchema = z.object({
    color: z.string(),
    colorGuid: z.string(),
    productint: z.number().int()
});

const updateColorSchema = z.object({
    color: z.string().optional(),
    colorGuid: z.string().optional(),
    productint: z.number().int().optional()
});

module.exports = {ColorSchema, updateColorSchema};
