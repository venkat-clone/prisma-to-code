
const { z } = require('zod');
const UserSchema = z.object({
    mobile: z.string(),
    name: z.string().optional(),
    inactive: z.boolean().default(false),
    age: z.number().int().default(0),
    isAdmin: z.boolean().default(false)
});

const updateUserSchema = z.object({
    mobile: z.string().optional(),
    name: z.string().optional(),
    inactive: z.boolean().default(false).optional(),
    age: z.number().int().default(0).optional(),
    isAdmin: z.boolean().default(false).optional()
});

module.exports = {UserSchema, updateUserSchema};
