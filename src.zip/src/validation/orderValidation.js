
const { z } = require('zod');
const OrderSchema = z.object({
    userId: z.number().int(),
    total: z.number().int(),
    addressid: z.number().int(),
    paymentId: z.number().int().optional(),
    status: z.enum(['PENDING', 'PROCESSING', 'DISPATCHED', 'SHIPPED', 'DELIVERED', 'CANCELLED'])
});

const updateOrderSchema = z.object({
    userId: z.number().int().optional(),
    total: z.number().int().optional(),
    addressid: z.number().int().optional(),
    paymentId: z.number().int().optional(),
    status: z.enum(['PENDING', 'PROCESSING', 'DISPATCHED', 'SHIPPED', 'DELIVERED', 'CANCELLED']).optional()
});

module.exports = {OrderSchema, updateOrderSchema};
