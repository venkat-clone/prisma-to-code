
const { z } = require('zod');
const ProductSchema = z.object({
    name: z.string(),
    description: z.string(),
    timerid: z.number().int().optional()
});

const updateProductSchema = z.object({
    name: z.string().optional(),
    description: z.string().optional(),
    timerid: z.number().int().optional()
});

module.exports = {ProductSchema, updateProductSchema};
