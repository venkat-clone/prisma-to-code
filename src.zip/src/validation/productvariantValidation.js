
const { z } = require('zod');
const ProductVariantSchema = z.object({
    productId: z.number().int(),
    sizeId: z.number().int(),
    colorId: z.number().int(),
    quantity: z.number().int(),
    sku: z.string().optional()
});

const updateProductVariantSchema = z.object({
    productId: z.number().int().optional(),
    sizeId: z.number().int().optional(),
    colorId: z.number().int().optional(),
    quantity: z.number().int().optional(),
    sku: z.string().optional()
});

module.exports = {ProductVariantSchema, updateProductVariantSchema};
