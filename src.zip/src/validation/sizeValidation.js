
const { z } = require('zod');
const SizeSchema = z.object({
    size: z.string(),
    sizeGuid: z.string(),
    productint: z.number().int()
});

const updateSizeSchema = z.object({
    size: z.string().optional(),
    sizeGuid: z.string().optional(),
    productint: z.number().int().optional()
});

module.exports = {SizeSchema, updateSizeSchema};
