
const { z } = require('zod');
const AddressSchema = z.object({
    address: z.string(),
    pincode: z.number().int(),
    isPrimary: z.boolean().default(false),
    userid: z.number().int()
});

const updateAddressSchema = z.object({
    address: z.string().optional(),
    pincode: z.number().int().optional(),
    isPrimary: z.boolean().default(false).optional(),
    userid: z.number().int().optional()
});

module.exports = {AddressSchema, updateAddressSchema};
