
const { z } = require('zod');
const TimerSchema = z.object({
    name: z.string(),
    discription: z.string(),
    discount: z.number().int(),
    endson: z.date()
});

const updateTimerSchema = z.object({
    name: z.string().optional(),
    discription: z.string().optional(),
    discount: z.number().int().optional(),
    endson: z.date().optional()
});

module.exports = {TimerSchema, updateTimerSchema};
