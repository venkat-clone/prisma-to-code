const CartRepository = require('../repositories/cartRepository');

const getCartById = async (id) => {
    return await CartRepository.getCartById(id);
};

const createCart = async (data, undefined, options = {}) => {
    return await CartRepository.createCart(data, undefined, options);
};

const updateCart = async (id, data) => {
    return await CartRepository.updateCart(id, data);
};

const deleteCart = async (id) => {
    return await CartRepository.deleteCart(id);
};

const getCarts = async (where, skip, take, orderBy, options = {}) => {
    return await CartRepository.getCarts(where, skip, take, orderBy, options);
};

module.exports = {
    getCartById,
    createCart,
    updateCart,
    deleteCart,
    getCarts
};