const ColorRepository = require('../repositories/colorRepository');

const getColorById = async (id) => {
    return await ColorRepository.getColorById(id);
};

const createColor = async (data, undefined, options = {}) => {
    return await ColorRepository.createColor(data, undefined, options);
};

const updateColor = async (id, data) => {
    return await ColorRepository.updateColor(id, data);
};

const deleteColor = async (id) => {
    return await ColorRepository.deleteColor(id);
};

const getColors = async (where, skip, take, orderBy, options = {}) => {
    return await ColorRepository.getColors(where, skip, take, orderBy, options);
};

module.exports = {
    getColorById,
    createColor,
    updateColor,
    deleteColor,
    getColors
};