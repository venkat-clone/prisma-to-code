const AddressRepository = require('../repositories/addressRepository');

const getAddressById = async (id) => {
    return await AddressRepository.getAddressById(id);
};

const createAddress = async (data, undefined, options = {}) => {
    return await AddressRepository.createAddress(data, undefined, options);
};

const updateAddress = async (id, data) => {
    return await AddressRepository.updateAddress(id, data);
};

const deleteAddress = async (id) => {
    return await AddressRepository.deleteAddress(id);
};

const getAddresss = async (where, skip, take, orderBy, options = {}) => {
    return await AddressRepository.getAddresss(where, skip, take, orderBy, options);
};

module.exports = {
    getAddressById,
    createAddress,
    updateAddress,
    deleteAddress,
    getAddresss
};