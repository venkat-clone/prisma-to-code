const PaymentRepository = require('../repositories/paymentRepository');

const getPaymentById = async (id) => {
    return await PaymentRepository.getPaymentById(id);
};

const createPayment = async (data, undefined, options = {}) => {
    return await PaymentRepository.createPayment(data, undefined, options);
};

const updatePayment = async (id, data) => {
    return await PaymentRepository.updatePayment(id, data);
};

const deletePayment = async (id) => {
    return await PaymentRepository.deletePayment(id);
};

const getPayments = async (where, skip, take, orderBy, options = {}) => {
    return await PaymentRepository.getPayments(where, skip, take, orderBy, options);
};

module.exports = {
    getPaymentById,
    createPayment,
    updatePayment,
    deletePayment,
    getPayments
};