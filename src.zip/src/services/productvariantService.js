const ProductVariantRepository = require('../repositories/productvariantRepository');

const getProductVariantById = async (id) => {
    return await ProductVariantRepository.getProductVariantById(id);
};

const createProductVariant = async (data, undefined, options = {}) => {
    return await ProductVariantRepository.createProductVariant(data, undefined, options);
};

const updateProductVariant = async (id, data) => {
    return await ProductVariantRepository.updateProductVariant(id, data);
};

const deleteProductVariant = async (id) => {
    return await ProductVariantRepository.deleteProductVariant(id);
};

const getProductVariants = async (where, skip, take, orderBy, options = {}) => {
    return await ProductVariantRepository.getProductVariants(where, skip, take, orderBy, options);
};

module.exports = {
    getProductVariantById,
    createProductVariant,
    updateProductVariant,
    deleteProductVariant,
    getProductVariants
};