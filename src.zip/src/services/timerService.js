const TimerRepository = require('../repositories/timerRepository');

const getTimerById = async (id) => {
    return await TimerRepository.getTimerById(id);
};

const createTimer = async (data, undefined, options = {}) => {
    return await TimerRepository.createTimer(data, undefined, options);
};

const updateTimer = async (id, data) => {
    return await TimerRepository.updateTimer(id, data);
};

const deleteTimer = async (id) => {
    return await TimerRepository.deleteTimer(id);
};

const getTimers = async (where, skip, take, orderBy, options = {}) => {
    return await TimerRepository.getTimers(where, skip, take, orderBy, options);
};

module.exports = {
    getTimerById,
    createTimer,
    updateTimer,
    deleteTimer,
    getTimers
};