const SizeRepository = require('../repositories/sizeRepository');

const getSizeById = async (id) => {
    return await SizeRepository.getSizeById(id);
};

const createSize = async (data, undefined, options = {}) => {
    return await SizeRepository.createSize(data, undefined, options);
};

const updateSize = async (id, data) => {
    return await SizeRepository.updateSize(id, data);
};

const deleteSize = async (id) => {
    return await SizeRepository.deleteSize(id);
};

const getSizes = async (where, skip, take, orderBy, options = {}) => {
    return await SizeRepository.getSizes(where, skip, take, orderBy, options);
};

module.exports = {
    getSizeById,
    createSize,
    updateSize,
    deleteSize,
    getSizes
};