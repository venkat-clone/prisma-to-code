const ProductRepository = require('../repositories/productRepository');

const getProductById = async (id) => {
    return await ProductRepository.getProductById(id);
};

const createProduct = async (data, undefined, options = {}) => {
    return await ProductRepository.createProduct(data, undefined, options);
};

const updateProduct = async (id, data) => {
    return await ProductRepository.updateProduct(id, data);
};

const deleteProduct = async (id) => {
    return await ProductRepository.deleteProduct(id);
};

const getProducts = async (where, skip, take, orderBy, options = {}) => {
    return await ProductRepository.getProducts(where, skip, take, orderBy, options);
};

module.exports = {
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct,
    getProducts
};