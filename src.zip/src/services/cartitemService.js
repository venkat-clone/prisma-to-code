const CartItemRepository = require('../repositories/cartitemRepository');

const getCartItemById = async (id) => {
    return await CartItemRepository.getCartItemById(id);
};

const createCartItem = async (data, undefined, options = {}) => {
    return await CartItemRepository.createCartItem(data, undefined, options);
};

const updateCartItem = async (id, data) => {
    return await CartItemRepository.updateCartItem(id, data);
};

const deleteCartItem = async (id) => {
    return await CartItemRepository.deleteCartItem(id);
};

const getCartItems = async (where, skip, take, orderBy, options = {}) => {
    return await CartItemRepository.getCartItems(where, skip, take, orderBy, options);
};

module.exports = {
    getCartItemById,
    createCartItem,
    updateCartItem,
    deleteCartItem,
    getCartItems
};