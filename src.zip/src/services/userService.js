const UserRepository = require('../repositories/userRepository');

const getUserById = async (id) => {
    return await UserRepository.getUserById(id);
};

const createUser = async (data, undefined, options = {}) => {
    return await UserRepository.createUser(data, undefined, options);
};

const updateUser = async (id, data) => {
    return await UserRepository.updateUser(id, data);
};

const deleteUser = async (id) => {
    return await UserRepository.deleteUser(id);
};

const getUsers = async (where, skip, take, orderBy, options = {}) => {
    return await UserRepository.getUsers(where, skip, take, orderBy, options);
};

module.exports = {
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    getUsers
};