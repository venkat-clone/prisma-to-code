const OrderItemRepository = require('../repositories/orderitemRepository');

const getOrderItemById = async (id) => {
    return await OrderItemRepository.getOrderItemById(id);
};

const createOrderItem = async (data, undefined, options = {}) => {
    return await OrderItemRepository.createOrderItem(data, undefined, options);
};

const updateOrderItem = async (id, data) => {
    return await OrderItemRepository.updateOrderItem(id, data);
};

const deleteOrderItem = async (id) => {
    return await OrderItemRepository.deleteOrderItem(id);
};

const getOrderItems = async (where, skip, take, orderBy, options = {}) => {
    return await OrderItemRepository.getOrderItems(where, skip, take, orderBy, options);
};

module.exports = {
    getOrderItemById,
    createOrderItem,
    updateOrderItem,
    deleteOrderItem,
    getOrderItems
};