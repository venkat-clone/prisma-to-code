const OrderRepository = require('../repositories/orderRepository');

const getOrderById = async (id) => {
    return await OrderRepository.getOrderById(id);
};

const createOrder = async (data, undefined, options = {}) => {
    return await OrderRepository.createOrder(data, undefined, options);
};

const updateOrder = async (id, data) => {
    return await OrderRepository.updateOrder(id, data);
};

const deleteOrder = async (id) => {
    return await OrderRepository.deleteOrder(id);
};

const getOrders = async (where, skip, take, orderBy, options = {}) => {
    return await OrderRepository.getOrders(where, skip, take, orderBy, options);
};

module.exports = {
    getOrderById,
    createOrder,
    updateOrder,
    deleteOrder,
    getOrders
};