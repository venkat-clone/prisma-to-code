
const express = require('express');
const router = express.Router();
const { OrderSchema, updateOrderSchema } = require('../validation/orderValidation');
const orderController = require('../controllers/orderController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Order
router.get('/', orderController.getOrders);
router.post('/', validateRequest(OrderSchema), orderController.createOrder);
router.get('/:id', orderController.getOrderById);
router.put('/:id', validateRequest(updateOrderSchema), orderController.updateOrder);
router.delete('/:id', orderController.deleteOrder);

module.exports = router;
