
const express = require('express');
const router = express.Router();
const { TimerSchema, updateTimerSchema } = require('../validation/timerValidation');
const timerController = require('../controllers/timerController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Timer
router.get('/', timerController.getTimers);
router.post('/', validateRequest(TimerSchema), timerController.createTimer);
router.get('/:id', timerController.getTimerById);
router.put('/:id', validateRequest(updateTimerSchema), timerController.updateTimer);
router.delete('/:id', timerController.deleteTimer);

module.exports = router;
