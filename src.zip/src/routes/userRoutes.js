
const express = require('express');
const router = express.Router();
const { UserSchema, updateUserSchema } = require('../validation/userValidation');
const userController = require('../controllers/userController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for User
router.get('/', userController.getUsers);
router.post('/', validateRequest(UserSchema), userController.createUser);
router.get('/:id', userController.getUserById);
router.put('/:id', validateRequest(updateUserSchema), userController.updateUser);
router.delete('/:id', userController.deleteUser);

module.exports = router;
