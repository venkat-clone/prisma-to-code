
const express = require('express');
const router = express.Router();
const { ColorSchema, updateColorSchema } = require('../validation/colorValidation');
const colorController = require('../controllers/colorController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Color
router.get('/', colorController.getColors);
router.post('/', validateRequest(ColorSchema), colorController.createColor);
router.get('/:id', colorController.getColorById);
router.put('/:id', validateRequest(updateColorSchema), colorController.updateColor);
router.delete('/:id', colorController.deleteColor);

module.exports = router;
