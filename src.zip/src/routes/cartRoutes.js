
const express = require('express');
const router = express.Router();
const { CartSchema, updateCartSchema } = require('../validation/cartValidation');
const cartController = require('../controllers/cartController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Cart
router.get('/', cartController.getCarts);
router.post('/', validateRequest(CartSchema), cartController.createCart);
router.get('/:id', cartController.getCartById);
router.put('/:id', validateRequest(updateCartSchema), cartController.updateCart);
router.delete('/:id', cartController.deleteCart);

module.exports = router;
