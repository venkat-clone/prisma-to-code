
const express = require('express');
const router = express.Router();
const { ProductVariantSchema, updateProductVariantSchema } = require('../validation/productvariantValidation');
const productvariantController = require('../controllers/productvariantController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for ProductVariant
router.get('/', productvariantController.getProductVariants);
router.post('/', validateRequest(ProductVariantSchema), productvariantController.createProductVariant);
router.get('/:id', productvariantController.getProductVariantById);
router.put('/:id', validateRequest(updateProductVariantSchema), productvariantController.updateProductVariant);
router.delete('/:id', productvariantController.deleteProductVariant);

module.exports = router;
