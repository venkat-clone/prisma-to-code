
// Automatically generated route exports
var express = require('express');
const indexRouter = express.Router();

const userRoutes = require('./userRoutes');
const addressRoutes = require('./addressRoutes');
const cartRoutes = require('./cartRoutes');
const cartitemRoutes = require('./cartitemRoutes');
const orderRoutes = require('./orderRoutes');
const orderitemRoutes = require('./orderitemRoutes');
const productRoutes = require('./productRoutes');
const sizeRoutes = require('./sizeRoutes');
const colorRoutes = require('./colorRoutes');
const productvariantRoutes = require('./productvariantRoutes');
const timerRoutes = require('./timerRoutes');
const paymentRoutes = require('./paymentRoutes');

indexRouter.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

module.exports = {
  userRoutes,
  addressRoutes,
  cartRoutes,
  cartitemRoutes,
  orderRoutes,
  orderitemRoutes,
  productRoutes,
  sizeRoutes,
  colorRoutes,
  productvariantRoutes,
  timerRoutes,
  paymentRoutes,
  indexRouter
};
