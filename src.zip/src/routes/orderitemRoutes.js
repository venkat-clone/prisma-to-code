
const express = require('express');
const router = express.Router();
const { OrderItemSchema, updateOrderItemSchema } = require('../validation/orderitemValidation');
const orderitemController = require('../controllers/orderitemController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for OrderItem
router.get('/', orderitemController.getOrderItems);
router.post('/', validateRequest(OrderItemSchema), orderitemController.createOrderItem);
router.get('/:id', orderitemController.getOrderItemById);
router.put('/:id', validateRequest(updateOrderItemSchema), orderitemController.updateOrderItem);
router.delete('/:id', orderitemController.deleteOrderItem);

module.exports = router;
