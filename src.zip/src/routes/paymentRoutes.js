
const express = require('express');
const router = express.Router();
const { PaymentSchema, updatePaymentSchema } = require('../validation/paymentValidation');
const paymentController = require('../controllers/paymentController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Payment
router.get('/', paymentController.getPayments);
router.post('/', validateRequest(PaymentSchema), paymentController.createPayment);
router.get('/:id', paymentController.getPaymentById);
router.put('/:id', validateRequest(updatePaymentSchema), paymentController.updatePayment);
router.delete('/:id', paymentController.deletePayment);

module.exports = router;
