
const express = require('express');
const router = express.Router();
const { AddressSchema, updateAddressSchema } = require('../validation/addressValidation');
const addressController = require('../controllers/addressController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Address
router.get('/', addressController.getAddresss);
router.post('/', validateRequest(AddressSchema), addressController.createAddress);
router.get('/:id', addressController.getAddressById);
router.put('/:id', validateRequest(updateAddressSchema), addressController.updateAddress);
router.delete('/:id', addressController.deleteAddress);

module.exports = router;
