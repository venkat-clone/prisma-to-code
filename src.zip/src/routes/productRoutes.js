
const express = require('express');
const router = express.Router();
const { ProductSchema, updateProductSchema } = require('../validation/productValidation');
const productController = require('../controllers/productController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Product
router.get('/', productController.getProducts);
router.post('/', validateRequest(ProductSchema), productController.createProduct);
router.get('/:id', productController.getProductById);
router.put('/:id', validateRequest(updateProductSchema), productController.updateProduct);
router.delete('/:id', productController.deleteProduct);

module.exports = router;
