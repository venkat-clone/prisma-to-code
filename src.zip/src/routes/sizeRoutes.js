
const express = require('express');
const router = express.Router();
const { SizeSchema, updateSizeSchema } = require('../validation/sizeValidation');
const sizeController = require('../controllers/sizeController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for Size
router.get('/', sizeController.getSizes);
router.post('/', validateRequest(SizeSchema), sizeController.createSize);
router.get('/:id', sizeController.getSizeById);
router.put('/:id', validateRequest(updateSizeSchema), sizeController.updateSize);
router.delete('/:id', sizeController.deleteSize);

module.exports = router;
