
const express = require('express');
const router = express.Router();
const { CartItemSchema, updateCartItemSchema } = require('../validation/cartitemValidation');
const cartitemController = require('../controllers/cartitemController');

// Middleware for validation
const validateRequest = (schema) => (req, res, next) => {
    const validationResult = schema.safeParse(req.body);
    if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.errors });
    }
    next();
};

// Define routes for CartItem
router.get('/', cartitemController.getCartItems);
router.post('/', validateRequest(CartItemSchema), cartitemController.createCartItem);
router.get('/:id', cartitemController.getCartItemById);
router.put('/:id', validateRequest(updateCartItemSchema), cartitemController.updateCartItem);
router.delete('/:id', cartitemController.deleteCartItem);

module.exports = router;
