const AddressService = require('../services/addressService');

const getAddressById = async (req, res) => {
    try {
        const address = await AddressService.getAddressById(req.params.id);
        res.json(address);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createAddress = async (req, res) => {
    try {
        const {  } = req.body;
        const newAddress = await AddressService.createAddress(req.body, );
        res.status(201).json(newAddress);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateAddress = async (req, res) => {
    try {
        const updatedAddress = await AddressService.updateAddress(req.params.id, req.body);
        res.json(updatedAddress);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteAddress = async (req, res) => {
    try {
        await AddressService.deleteAddress(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getAddresss = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.address ? {address: generateStringFilter(filters.address)} : {},
filters.pincode ? {pincode: generateIntegerFilter(filters.pincode)} : {},
filters.isPrimary ? {isPrimary: generateBooleanFilter(filters.isPrimary)} : {},
filters.userid ? {userid: generateIntegerFilter(filters.userid)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "address", "pincode", "isPrimary", "userid"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await AddressService.getAddresss(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getAddressById,
    createAddress,
    updateAddress,
    deleteAddress,
    getAddresss
};