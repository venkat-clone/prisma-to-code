const OrderItemService = require('../services/orderitemService');

const getOrderItemById = async (req, res) => {
    try {
        const orderitem = await OrderItemService.getOrderItemById(req.params.id);
        res.json(orderitem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createOrderItem = async (req, res) => {
    try {
        const {  } = req.body;
        const newOrderItem = await OrderItemService.createOrderItem(req.body, );
        res.status(201).json(newOrderItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateOrderItem = async (req, res) => {
    try {
        const updatedOrderItem = await OrderItemService.updateOrderItem(req.params.id, req.body);
        res.json(updatedOrderItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteOrderItem = async (req, res) => {
    try {
        await OrderItemService.deleteOrderItem(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getOrderItems = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.cartId ? {cartId: generateIntegerFilter(filters.cartId)} : {},
filters.productId ? {productId: generateIntegerFilter(filters.productId)} : {},
filters.quantity ? {quantity: generateIntegerFilter(filters.quantity)} : {},
filters.price ? {price: generateIntegerFilter(filters.price)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "cartId", "productId", "quantity", "price"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await OrderItemService.getOrderItems(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getOrderItemById,
    createOrderItem,
    updateOrderItem,
    deleteOrderItem,
    getOrderItems
};