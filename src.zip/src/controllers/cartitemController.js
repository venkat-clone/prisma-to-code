const CartItemService = require('../services/cartitemService');

const getCartItemById = async (req, res) => {
    try {
        const cartitem = await CartItemService.getCartItemById(req.params.id);
        res.json(cartitem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createCartItem = async (req, res) => {
    try {
        const {  } = req.body;
        const newCartItem = await CartItemService.createCartItem(req.body, );
        res.status(201).json(newCartItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateCartItem = async (req, res) => {
    try {
        const updatedCartItem = await CartItemService.updateCartItem(req.params.id, req.body);
        res.json(updatedCartItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteCartItem = async (req, res) => {
    try {
        await CartItemService.deleteCartItem(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getCartItems = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.cartId ? {cartId: generateIntegerFilter(filters.cartId)} : {},
filters.productId ? {productId: generateIntegerFilter(filters.productId)} : {},
filters.quantity ? {quantity: generateIntegerFilter(filters.quantity)} : {},
filters.price ? {price: generateIntegerFilter(filters.price)} : {},
filters.sizeid ? {sizeid: generateIntegerFilter(filters.sizeid)} : {},
filters.colorid ? {colorid: generateIntegerFilter(filters.colorid)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "cartId", "productId", "quantity", "price", "sizeid", "colorid"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await CartItemService.getCartItems(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getCartItemById,
    createCartItem,
    updateCartItem,
    deleteCartItem,
    getCartItems
};