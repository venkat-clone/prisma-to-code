const UserService = require('../services/userService');

const getUserById = async (req, res) => {
    try {
        const user = await UserService.getUserById(req.params.id);
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createUser = async (req, res) => {
    try {
        const {  } = req.body;
        const newUser = await UserService.createUser(req.body, );
        res.status(201).json(newUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateUser = async (req, res) => {
    try {
        const updatedUser = await UserService.updateUser(req.params.id, req.body);
        res.json(updatedUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteUser = async (req, res) => {
    try {
        await UserService.deleteUser(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getUsers = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.mobile ? {mobile: generateStringFilter(filters.mobile)} : {},
filters.name ? {name: generateStringFilter(filters.name)} : {},
filters.inactive ? {inactive: generateBooleanFilter(filters.inactive)} : {},
filters.age ? {age: generateIntegerFilter(filters.age)} : {},
filters.isAdmin ? {isAdmin: generateBooleanFilter(filters.isAdmin)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "mobile", "name", "inactive", "age", "isAdmin"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await UserService.getUsers(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    getUsers
};