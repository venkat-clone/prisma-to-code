const ColorService = require('../services/colorService');

const getColorById = async (req, res) => {
    try {
        const color = await ColorService.getColorById(req.params.id);
        res.json(color);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createColor = async (req, res) => {
    try {
        const {  } = req.body;
        const newColor = await ColorService.createColor(req.body, );
        res.status(201).json(newColor);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateColor = async (req, res) => {
    try {
        const updatedColor = await ColorService.updateColor(req.params.id, req.body);
        res.json(updatedColor);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteColor = async (req, res) => {
    try {
        await ColorService.deleteColor(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getColors = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.color ? {color: generateStringFilter(filters.color)} : {},
filters.colorGuid ? {colorGuid: generateStringFilter(filters.colorGuid)} : {},
filters.productint ? {productint: generateIntegerFilter(filters.productint)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "color", "colorGuid", "productint"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await ColorService.getColors(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getColorById,
    createColor,
    updateColor,
    deleteColor,
    getColors
};