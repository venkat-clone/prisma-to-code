const OrderService = require('../services/orderService');

const getOrderById = async (req, res) => {
    try {
        const order = await OrderService.getOrderById(req.params.id);
        res.json(order);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createOrder = async (req, res) => {
    try {
        const {  } = req.body;
        const newOrder = await OrderService.createOrder(req.body, );
        res.status(201).json(newOrder);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateOrder = async (req, res) => {
    try {
        const updatedOrder = await OrderService.updateOrder(req.params.id, req.body);
        res.json(updatedOrder);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteOrder = async (req, res) => {
    try {
        await OrderService.deleteOrder(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getOrders = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.userId ? {userId: generateIntegerFilter(filters.userId)} : {},
filters.total ? {total: generateIntegerFilter(filters.total)} : {},
filters.addressid ? {addressid: generateIntegerFilter(filters.addressid)} : {},
filters.paymentId ? {paymentId: generateIntegerFilter(filters.paymentId)} : {},
filters.status ? {status: generateEnumFilter(filters.status)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "userId", "total", "addressid", "paymentId", "status"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await OrderService.getOrders(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getOrderById,
    createOrder,
    updateOrder,
    deleteOrder,
    getOrders
};