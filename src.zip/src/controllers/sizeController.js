const SizeService = require('../services/sizeService');

const getSizeById = async (req, res) => {
    try {
        const size = await SizeService.getSizeById(req.params.id);
        res.json(size);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createSize = async (req, res) => {
    try {
        const {  } = req.body;
        const newSize = await SizeService.createSize(req.body, );
        res.status(201).json(newSize);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateSize = async (req, res) => {
    try {
        const updatedSize = await SizeService.updateSize(req.params.id, req.body);
        res.json(updatedSize);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteSize = async (req, res) => {
    try {
        await SizeService.deleteSize(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getSizes = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.size ? {size: generateStringFilter(filters.size)} : {},
filters.sizeGuid ? {sizeGuid: generateStringFilter(filters.sizeGuid)} : {},
filters.productint ? {productint: generateIntegerFilter(filters.productint)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "size", "sizeGuid", "productint"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await SizeService.getSizes(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getSizeById,
    createSize,
    updateSize,
    deleteSize,
    getSizes
};