const TimerService = require('../services/timerService');

const getTimerById = async (req, res) => {
    try {
        const timer = await TimerService.getTimerById(req.params.id);
        res.json(timer);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createTimer = async (req, res) => {
    try {
        const {  } = req.body;
        const newTimer = await TimerService.createTimer(req.body, );
        res.status(201).json(newTimer);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateTimer = async (req, res) => {
    try {
        const updatedTimer = await TimerService.updateTimer(req.params.id, req.body);
        res.json(updatedTimer);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteTimer = async (req, res) => {
    try {
        await TimerService.deleteTimer(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getTimers = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.name ? {name: generateStringFilter(filters.name)} : {},
filters.discription ? {discription: generateStringFilter(filters.discription)} : {},
filters.discount ? {discount: generateIntegerFilter(filters.discount)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "name", "discription", "discount"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await TimerService.getTimers(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getTimerById,
    createTimer,
    updateTimer,
    deleteTimer,
    getTimers
};