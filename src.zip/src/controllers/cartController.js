const CartService = require('../services/cartService');

const getCartById = async (req, res) => {
    try {
        const cart = await CartService.getCartById(req.params.id);
        res.json(cart);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createCart = async (req, res) => {
    try {
        const {  } = req.body;
        const newCart = await CartService.createCart(req.body, );
        res.status(201).json(newCart);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateCart = async (req, res) => {
    try {
        const updatedCart = await CartService.updateCart(req.params.id, req.body);
        res.json(updatedCart);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteCart = async (req, res) => {
    try {
        await CartService.deleteCart(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getCarts = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.userId ? {userId: generateIntegerFilter(filters.userId)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "userId"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await CartService.getCarts(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getCartById,
    createCart,
    updateCart,
    deleteCart,
    getCarts
};