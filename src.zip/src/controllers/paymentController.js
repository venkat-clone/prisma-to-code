const PaymentService = require('../services/paymentService');

const getPaymentById = async (req, res) => {
    try {
        const payment = await PaymentService.getPaymentById(req.params.id);
        res.json(payment);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createPayment = async (req, res) => {
    try {
        const {  } = req.body;
        const newPayment = await PaymentService.createPayment(req.body, );
        res.status(201).json(newPayment);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updatePayment = async (req, res) => {
    try {
        const updatedPayment = await PaymentService.updatePayment(req.params.id, req.body);
        res.json(updatedPayment);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deletePayment = async (req, res) => {
    try {
        await PaymentService.deletePayment(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getPayments = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.status ? {status: generateEnumFilter(filters.status)} : {},
filters.type ? {type: generateEnumFilter(filters.type)} : {},
filters.amount ? {amount: generateIntegerFilter(filters.amount)} : {},
filters.orderId ? {orderId: generateIntegerFilter(filters.orderId)} : {},
filters.TransactionId ? {TransactionId: generateStringFilter(filters.TransactionId)} : {},
filters.from ? {from: generateStringFilter(filters.from)} : {},
filters.to ? {to: generateStringFilter(filters.to)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "status", "type", "amount", "orderId", "TransactionId", "from", "to"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await PaymentService.getPayments(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getPaymentById,
    createPayment,
    updatePayment,
    deletePayment,
    getPayments
};