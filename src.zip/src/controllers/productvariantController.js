const ProductVariantService = require('../services/productvariantService');

const getProductVariantById = async (req, res) => {
    try {
        const productvariant = await ProductVariantService.getProductVariantById(req.params.id);
        res.json(productvariant);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const createProductVariant = async (req, res) => {
    try {
        const {  } = req.body;
        const newProductVariant = await ProductVariantService.createProductVariant(req.body, );
        res.status(201).json(newProductVariant);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateProductVariant = async (req, res) => {
    try {
        const updatedProductVariant = await ProductVariantService.updateProductVariant(req.params.id, req.body);
        res.json(updatedProductVariant);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const deleteProductVariant = async (req, res) => {
    try {
        await ProductVariantService.deleteProductVariant(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const getProductVariants = async (req, res) => {
    try {
        const { search, page = 1, limit = 10, sortBy = 'id', sortOrder = 'asc', ...filters } = req.query;
        const currentPage = Math.max(1, parseInt(page, 10));
        const pageSize = Math.max(1, parseInt(limit, 10));
        const skip = (currentPage - 1) * pageSize;
        
        const where = {
            AND: [
                filters.id ? {id: generateIntegerFilter(filters.id)} : {},
filters.productId ? {productId: generateIntegerFilter(filters.productId)} : {},
filters.sizeId ? {sizeId: generateIntegerFilter(filters.sizeId)} : {},
filters.colorId ? {colorId: generateIntegerFilter(filters.colorId)} : {},
filters.quantity ? {quantity: generateIntegerFilter(filters.quantity)} : {},
filters.sku ? {sku: generateStringFilter(filters.sku)} : {}
            ].filter(Boolean),
        };

        const validFields = ["id", "productId", "sizeId", "colorId", "quantity", "sku"];
        const orderBy = validFields.includes(sortBy) ? { [sortBy]: sortOrder === 'desc' ? 'desc' : 'asc' } : { id: 'asc' };

        const { orders, count } = await ProductVariantService.getProductVariants(where, skip, pageSize, orderBy);

        res.status(200).json({
            data: orders,
            meta: {
                totalItems: count,
                totalPages: Math.ceil(count / pageSize),
                currentPage,
                pageSize
            }
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }

};

module.exports = {
    getProductVariantById,
    createProductVariant,
    updateProductVariant,
    deleteProductVariant,
    getProductVariants
};